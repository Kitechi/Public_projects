#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QDebug>
#include <QByteArray>
#include <QDataStream>
#include <QPlainTextEdit>
#include <QDir>
#include <QFile>
#include <QtEndian>
#include <QList>
#include <QMessageBox>
#include <QString>
#include <QThread>







QByteArray readData = 0;
qint16 int16_Data[5000];
QByteArray voltage = 0;
QByteArray hex_Data = 0;
QByteArray readData2 = 0;

bool result1;

QVector<double> y_pt;

int len_hex = 0;
int len = 0;
int flag_f = 0;
int flag_a = 0;

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->line_ipAddress->setText("192.168.1.1");
    ui->line_Port->setText("1000");

}

MainWindow::~MainWindow()
{
    hex_Data.clear();
    readData.clear();
    clear_plot();
    delete ui;
}

void MainWindow::doConnect(const QString IP, const int Port, QString &Status)
{
    socket = new QTcpSocket(this);

    connect(socket, SIGNAL(readyRead()),this, SLOT(cont_ReadData()));
    socket->connectToHost(IP, Port);
    qDebug() << IP << " and port = " << Port;

    if(socket->waitForConnected(3000))
    {
        Status = "Connected to " + IP + ".";
    }
    else
    {
        Status = "Not connected to " + IP + ".";
    }
}

void MainWindow::cont_ReadData()
{
    readData = socket->readAll();
    if (readData.contains("status")){

        if (readData.contains("sending")){
            ui->plainTextEdit->insertPlainText("WUD: Data Sending\n");
        }
        if (readData.contains("binded")){
            ui->plainTextEdit->insertPlainText("WUD: Data Binded\n");
        }

        if (readData.contains("f050")){
            ui->plainTextEdit->insertPlainText("WUD: 50 kHz Set\n");
            flag_f=1;
        }
        if (readData.contains("f100")){
            ui->plainTextEdit->insertPlainText("WUD: 100 kHz Set\n");
            flag_f=1;
        }
        if (readData.contains("f150")){
            ui->plainTextEdit->insertPlainText("WUD: 150 kHz Set\n");
            flag_f=1;
        }
        if (readData.contains("f200")){
            ui->plainTextEdit->insertPlainText("WUD: 200 kHz Set\n");
            flag_f=1;
        }
        if (readData.contains("f250")){
            ui->plainTextEdit->insertPlainText("WUD: 250 kHz Set\n");
            flag_f=1;
        }
        if (readData.contains("a001")){
            ui->plainTextEdit->insertPlainText("WUD: AVG 1 Set\n");
            flag_a=1;
        }
        if (readData.contains("a002")){
            ui->plainTextEdit->insertPlainText("WUD: AVG 2 Set\n");
            flag_a=1;
        }
        if (readData.contains("a004")){
            ui->plainTextEdit->insertPlainText("WUD: AVG 4 Set\n");
            flag_a=1;
        }
        if (readData.contains("a008")){
            ui->plainTextEdit->insertPlainText("WUD: AVG 8 Set\n");
            flag_a=1;
        }
        if (readData.contains("a016")){
            ui->plainTextEdit->insertPlainText("WUD: AVG 16 Set\n");
            flag_a=1;
        }
        if (readData.contains("a032")){
            ui->plainTextEdit->insertPlainText("WUD: AVG 32 Set\n");
            flag_a=1;
        }



    }

    else {
        readData2.append(readData);
        hex_Data.append(readData.toHex());
        qDebug() << "hex_Data " << hex_Data.size();

        if(hex_Data.size() % 20000==0){
            ui->plainTextEdit->insertPlainText("Transfer Complete\n\END\n\n");
            my_plot(readData2);
        }
    }


}



void MainWindow::on_pushBtn_Measure_clicked()
{
    ui->plainTextEdit->clear();
    readData.clear();
    hex_Data.clear();
    readData2.clear();
    clear_plot();

    QString IP = ui->line_ipAddress->text();
    int Port = ui->line_Port->text().toInt();

    QString status;
    doConnect(IP, Port, status);
    ui->plainTextEdit->insertPlainText("Connecting to WUD\n");



//    ui->plainTextEdit->insertPlainText("Clear Done\n");

    QByteArray cmd_WUD1 = ui->comboBox_1->currentText().toLocal8Bit();
    socket->write(cmd_WUD1);
    socket->waitForBytesWritten(10);

//    ui->plainTextEdit->insertPlainText("Frequency Set\n");

QThread::msleep(600);

    QByteArray cmd_WUD3 = ui->comboBox_3->currentText().toLocal8Bit();
    socket->write(cmd_WUD3);
    socket->waitForBytesWritten(10);

//    ui->plainTextEdit->insertPlainText("Averaging Set\n");

QThread::msleep(600);

    QByteArray cmd_WUD = "start";
    socket->write(cmd_WUD);
    socket->waitForBytesWritten(10);



}

/*
void MainWindow::on_pushBtn_Send_clicked()
{
    QString cmd = ui->line_Command->text();
    if (cmd == "G")
    {
        qDebug() << "before " << hex_Data.size();
        readData.clear();
        hex_Data.clear();
        qDebug() << "after " << hex_Data.size();
    }
    QByteArray cmd_WUD = ui->line_Command->text().toLocal8Bit();

    socket->write(cmd_WUD);
    socket->waitForBytesWritten(10);
}
*/








void MainWindow::on_pushBtn_Save_clicked()
{
    //Converting Hex to Int

    QByteArray t;
    QByteArray tt;

    len = hex_Data.size();
    //int numConverted = len/4;
    qDebug() << len << "and " << len/4;

    for (int i = 0; i < len/4; ++i)
    {
        t[0] = hex_Data[2 + 4*i];
        t[1] = hex_Data[3 + 4*i];
        t[2] = hex_Data[0 + 4*i];
        t[3] = hex_Data[1 + 4*i];

        tt.append(t);
        int16_Data[i] = t.toInt(0,16)*0.8057;


    }
//    ui->plainTextEdit->insertPlainText(QString (tt)+"\nEND\n\n");
    ui->plainTextEdit->insertPlainText("Hex Converted\nEND\n\n");
    t.clear();
    tt.clear();

    // File saving

    //QString:: Freq = QString:: ui->comboBox_1->currentText()


    QFile file(ui->line_Command_2->text()+" "+ui->comboBox_1->currentText()+" "+ui->comboBox_3->currentText()+".txt");

    if(!file.open(QFile::WriteOnly))
    {
        QMessageBox errBox;
        errBox.setText("Could not open file for writing.");
        errBox.exec();
        return;
    }

    QString tab = "\r\n";

            qDebug() << "y_pt size"+ y_pt.size();
            qDebug() << "len size"+ len;
 //           qDebug() << "int16 size"+ int16_Data.size();

    for(int i=0; i < len/4; ++i)
    {
        QTextStream out(&file);
        out << int16_Data[i];
        out << tab;
    }

    qDebug() << y_pt;

    file.flush();
    file.close();

    ui->plainTextEdit->insertPlainText("File Saved\nEND\n\n");
}

void MainWindow::my_plot(QByteArray sig)
{


        qDebug() << "sig size"+ sig.size();
        QVector<double> byte1,byte0,x_pt,y_pt,y_pt1,y_pt2,y_pt3,y_pt4,y_pt5;


        for (int i=0; i < (sig.size()/2)-1;++i){
            byte1<<sig[i*2+1];
            byte0<<sig[i*2];


            if (byte0[i] < 0){
                y_pt<<(256*(byte1[i]))+((256)+byte0[i]);
            }
            else{
                y_pt<<256*(byte1[i])+(byte0[i]);
            }

        }

        for (int i=0; i<(sig.size()/2/5)-1;++i){
            x_pt<<i/2.27;
            y_pt1<<y_pt[i]*0.8057;
            y_pt2<<y_pt[i+1*(sig.size()/2/5)]*0.8057;
            y_pt3<<y_pt[i+2*(sig.size()/2/5)]*0.8057;
            y_pt4<<y_pt[i+3*(sig.size()/2/5)]*0.8057;
            y_pt5<<y_pt[i+4*(sig.size()/2/5)]*0.8057;
        }

        ui->customPlot1->addGraph();
        ui->customPlot1->graph(0)->setData(x_pt,y_pt1);
        ui->customPlot1->xAxis->setLabel("Time [us]");
        ui->customPlot1->yAxis->setLabel("Voltage [mV]");
        ui->customPlot1->xAxis->setRange(0,300);
        ui->customPlot1->yAxis->setRange(0,3300);
        ui->customPlot1->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom | QCP::iSelectAxes |
                                          QCP::iSelectLegend | QCP::iSelectPlottables);
        ui->customPlot1->replot();

        ui->customPlot2->addGraph();
        ui->customPlot2->graph(0)->setData(x_pt,y_pt2);
        ui->customPlot2->xAxis->setLabel("Time [us]");
        ui->customPlot2->yAxis->setLabel("Voltage [mV]");
        ui->customPlot2->xAxis->setRange(0,300);
        ui->customPlot2->yAxis->setRange(0,3300);
        ui->customPlot2->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom | QCP::iSelectAxes |
                                          QCP::iSelectLegend | QCP::iSelectPlottables);
        ui->customPlot2->replot();


        ui->customPlot3->addGraph();
        ui->customPlot3->graph(0)->setData(x_pt,y_pt3);
        ui->customPlot3->xAxis->setLabel("Time [us]");
        ui->customPlot3->yAxis->setLabel("Voltage [mV]");
        ui->customPlot3->xAxis->setRange(0,300);
        ui->customPlot3->yAxis->setRange(0,3300);
        ui->customPlot3->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom | QCP::iSelectAxes |
                                          QCP::iSelectLegend | QCP::iSelectPlottables);
        ui->customPlot3->replot();

        ui->customPlot4->addGraph();
        ui->customPlot4->graph(0)->setData(x_pt,y_pt4);
        ui->customPlot4->xAxis->setLabel("Time [us]");
        ui->customPlot4->yAxis->setLabel("Voltage [mV]");
        ui->customPlot4->xAxis->setRange(0,300);
        ui->customPlot4->yAxis->setRange(0,3300);
        ui->customPlot4->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom | QCP::iSelectAxes |
                                          QCP::iSelectLegend | QCP::iSelectPlottables);
        ui->customPlot4->replot();

        ui->customPlot5->addGraph();
        ui->customPlot5->graph(0)->setData(x_pt,y_pt5);
        ui->customPlot5->xAxis->setLabel("Time [us]");
        ui->customPlot5->yAxis->setLabel("Voltage [mV]");
        ui->customPlot5->xAxis->setRange(0,300);
        ui->customPlot5->yAxis->setRange(0,3300);
        ui->customPlot5->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom | QCP::iSelectAxes |
                                          QCP::iSelectLegend | QCP::iSelectPlottables);
        ui->customPlot5->replot();



}



void MainWindow::on_pushBtn_Auto_Scale_clicked()
{
    ui->customPlot1->rescaleAxes();
    ui->customPlot1->xAxis->setRange(0,300);
    ui->customPlot1->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom | QCP::iSelectPlottables);
    ui->customPlot1->replot();

    ui->customPlot2->rescaleAxes();
    ui->customPlot2->xAxis->setRange(0,300);
    ui->customPlot2->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom | QCP::iSelectPlottables);
    ui->customPlot2->replot();

    ui->customPlot3->rescaleAxes();
    ui->customPlot3->xAxis->setRange(0,300);
    ui->customPlot3->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom | QCP::iSelectPlottables);
    ui->customPlot3->replot();

    ui->customPlot4->rescaleAxes();
    ui->customPlot4->xAxis->setRange(0,300);
    ui->customPlot4->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom | QCP::iSelectPlottables);
    ui->customPlot4->replot();

    ui->customPlot5->rescaleAxes();
    ui->customPlot5->xAxis->setRange(0,300);
    ui->customPlot5->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom | QCP::iSelectPlottables);
    ui->customPlot5->replot();
}


void MainWindow::on_pushBtn_Zoom_Reset_clicked()
{
    ui->customPlot1->xAxis->setRange(0,300);
    ui->customPlot1->yAxis->setRange(0,3300);
    ui->customPlot1->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom | QCP::iSelectPlottables);
    ui->customPlot1->replot();

    ui->customPlot2->xAxis->setRange(0,300);
    ui->customPlot2->yAxis->setRange(0,3300);
    ui->customPlot2->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom | QCP::iSelectPlottables);
    ui->customPlot2->replot();

    ui->customPlot3->xAxis->setRange(0,300);
    ui->customPlot3->yAxis->setRange(0,3300);
    ui->customPlot3->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom | QCP::iSelectPlottables);
    ui->customPlot3->replot();

    ui->customPlot4->xAxis->setRange(0,300);
    ui->customPlot4->yAxis->setRange(0,3300);
    ui->customPlot4->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom | QCP::iSelectPlottables);
    ui->customPlot4->replot();

    ui->customPlot5->xAxis->setRange(0,300);
    ui->customPlot5->yAxis->setRange(0,3300);
    ui->customPlot5->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom | QCP::iSelectPlottables);
    ui->customPlot5->replot();
}

void MainWindow::clear_plot()
{
       ui->customPlot1->addGraph();
       ui->customPlot1->graph(0)->data()->clear();
       ui->customPlot1->replot();

       ui->customPlot2->addGraph();
       ui->customPlot2->graph(0)->data()->clear();
       ui->customPlot2->replot();

       ui->customPlot3->addGraph();
       ui->customPlot3->graph(0)->data()->clear();
       ui->customPlot3->replot();

       ui->customPlot4->addGraph();
       ui->customPlot4->graph(0)->data()->clear();
       ui->customPlot4->replot();

       ui->customPlot5->addGraph();
       ui->customPlot5->graph(0)->data()->clear();
       ui->customPlot5->replot();
}


void MainWindow::on_pushBtn_Clear_clicked()
{
    readData.clear();
    hex_Data.clear();
    readData2.clear();
    clear_plot();
    ui->plainTextEdit->clear();
}


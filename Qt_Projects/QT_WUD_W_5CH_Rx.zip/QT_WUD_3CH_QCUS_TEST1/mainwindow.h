#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QObject>
#include <QTcpSocket>
#include <QDebug>
#include <QByteArray>
#include <QWidget>


namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

    void doConnect(const QString IP, const int Port, QString & Status);
    void my_plot(QByteArray sig);
    void clear_plot();




private slots:
    void on_pushBtn_Measure_clicked();

    void on_pushBtn_Save_clicked();

    void cont_ReadData();

    void on_pushBtn_Clear_clicked();

    void on_pushBtn_Zoom_Reset_clicked();

    void on_pushBtn_Auto_Scale_clicked();




private:
    Ui::MainWindow *ui;
    QTcpSocket *socket;
};

#endif // MAINWINDOW_H

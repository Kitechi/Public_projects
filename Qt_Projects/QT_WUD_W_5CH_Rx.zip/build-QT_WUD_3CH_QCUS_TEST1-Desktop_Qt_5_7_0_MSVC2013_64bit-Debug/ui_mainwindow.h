/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>
#include "qcustomplot.h"

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QLineEdit *line_ipAddress;
    QLineEdit *line_Port;
    QLabel *label_ipAddress;
    QLabel *label_Port;
    QPushButton *pushBtn_Measure;
    QPushButton *pushBtn_Save;
    QPlainTextEdit *plainTextEdit;
    QComboBox *comboBox_1;
    QLineEdit *line_Command_2;
    QLabel *label_Command_2;
    QComboBox *comboBox_3;
    QLabel *label_Command_3;
    QLabel *label_Command_4;
    QCustomPlot *customPlot1;
    QPushButton *pushBtn_Clear;
    QPushButton *pushBtn_Zoom_Reset;
    QCustomPlot *customPlot2;
    QCustomPlot *customPlot3;
    QCustomPlot *customPlot4;
    QCustomPlot *customPlot5;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(1454, 946);
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(2);
        sizePolicy.setVerticalStretch(2);
        sizePolicy.setHeightForWidth(MainWindow->sizePolicy().hasHeightForWidth());
        MainWindow->setSizePolicy(sizePolicy);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        line_ipAddress = new QLineEdit(centralWidget);
        line_ipAddress->setObjectName(QStringLiteral("line_ipAddress"));
        line_ipAddress->setGeometry(QRect(40, 60, 91, 20));
        line_Port = new QLineEdit(centralWidget);
        line_Port->setObjectName(QStringLiteral("line_Port"));
        line_Port->setGeometry(QRect(140, 60, 51, 20));
        label_ipAddress = new QLabel(centralWidget);
        label_ipAddress->setObjectName(QStringLiteral("label_ipAddress"));
        label_ipAddress->setGeometry(QRect(40, 40, 81, 16));
        label_Port = new QLabel(centralWidget);
        label_Port->setObjectName(QStringLiteral("label_Port"));
        label_Port->setGeometry(QRect(140, 40, 31, 16));
        pushBtn_Measure = new QPushButton(centralWidget);
        pushBtn_Measure->setObjectName(QStringLiteral("pushBtn_Measure"));
        pushBtn_Measure->setGeometry(QRect(40, 220, 151, 41));
        pushBtn_Save = new QPushButton(centralWidget);
        pushBtn_Save->setObjectName(QStringLiteral("pushBtn_Save"));
        pushBtn_Save->setGeometry(QRect(40, 410, 151, 23));
        plainTextEdit = new QPlainTextEdit(centralWidget);
        plainTextEdit->setObjectName(QStringLiteral("plainTextEdit"));
        plainTextEdit->setGeometry(QRect(20, 490, 191, 421));
        comboBox_1 = new QComboBox(centralWidget);
        comboBox_1->setObjectName(QStringLiteral("comboBox_1"));
        comboBox_1->setGeometry(QRect(40, 120, 91, 22));
        line_Command_2 = new QLineEdit(centralWidget);
        line_Command_2->setObjectName(QStringLiteral("line_Command_2"));
        line_Command_2->setGeometry(QRect(40, 370, 151, 20));
        label_Command_2 = new QLabel(centralWidget);
        label_Command_2->setObjectName(QStringLiteral("label_Command_2"));
        label_Command_2->setGeometry(QRect(40, 350, 81, 16));
        comboBox_3 = new QComboBox(centralWidget);
        comboBox_3->setObjectName(QStringLiteral("comboBox_3"));
        comboBox_3->setGeometry(QRect(40, 180, 91, 22));
        label_Command_3 = new QLabel(centralWidget);
        label_Command_3->setObjectName(QStringLiteral("label_Command_3"));
        label_Command_3->setGeometry(QRect(40, 100, 191, 16));
        label_Command_4 = new QLabel(centralWidget);
        label_Command_4->setObjectName(QStringLiteral("label_Command_4"));
        label_Command_4->setGeometry(QRect(40, 160, 191, 16));
        customPlot1 = new QCustomPlot(centralWidget);
        customPlot1->setObjectName(QStringLiteral("customPlot1"));
        customPlot1->setGeometry(QRect(240, 70, 1201, 151));
        pushBtn_Clear = new QPushButton(centralWidget);
        pushBtn_Clear->setObjectName(QStringLiteral("pushBtn_Clear"));
        pushBtn_Clear->setGeometry(QRect(40, 450, 151, 23));
        pushBtn_Zoom_Reset = new QPushButton(centralWidget);
        pushBtn_Zoom_Reset->setObjectName(QStringLiteral("pushBtn_Zoom_Reset"));
        pushBtn_Zoom_Reset->setGeometry(QRect(40, 300, 151, 23));
        customPlot2 = new QCustomPlot(centralWidget);
        customPlot2->setObjectName(QStringLiteral("customPlot2"));
        customPlot2->setGeometry(QRect(240, 240, 1201, 151));
        customPlot3 = new QCustomPlot(centralWidget);
        customPlot3->setObjectName(QStringLiteral("customPlot3"));
        customPlot3->setGeometry(QRect(240, 410, 1201, 151));
        customPlot4 = new QCustomPlot(centralWidget);
        customPlot4->setObjectName(QStringLiteral("customPlot4"));
        customPlot4->setGeometry(QRect(240, 580, 1201, 151));
        customPlot5 = new QCustomPlot(centralWidget);
        customPlot5->setObjectName(QStringLiteral("customPlot5"));
        customPlot5->setGeometry(QRect(240, 750, 1201, 151));
        MainWindow->setCentralWidget(centralWidget);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "WUD GUI", 0));
        line_ipAddress->setText(QApplication::translate("MainWindow", "192.168.0.1", 0));
        line_Port->setText(QApplication::translate("MainWindow", "1000", 0));
        label_ipAddress->setText(QApplication::translate("MainWindow", "IP Address", 0));
        label_Port->setText(QApplication::translate("MainWindow", "Port", 0));
        pushBtn_Measure->setText(QApplication::translate("MainWindow", "Measure", 0));
        pushBtn_Save->setText(QApplication::translate("MainWindow", "Save", 0));
        comboBox_1->clear();
        comboBox_1->insertItems(0, QStringList()
         << QApplication::translate("MainWindow", "50 kHz", 0)
         << QApplication::translate("MainWindow", "100 kHz", 0)
         << QApplication::translate("MainWindow", "150 kHz", 0)
         << QApplication::translate("MainWindow", "200 kHz", 0)
         << QApplication::translate("MainWindow", "250 kHz", 0)
        );
        line_Command_2->setText(QString());
        label_Command_2->setText(QApplication::translate("MainWindow", "File Name", 0));
        comboBox_3->clear();
        comboBox_3->insertItems(0, QStringList()
         << QApplication::translate("MainWindow", "AVG 1", 0)
         << QApplication::translate("MainWindow", "AVG 2", 0)
         << QApplication::translate("MainWindow", "AVG 4", 0)
         << QApplication::translate("MainWindow", "AVG 8", 0)
         << QApplication::translate("MainWindow", "AVG 16", 0)
        );
        label_Command_3->setText(QApplication::translate("MainWindow", "Actuation Frequency", 0));
        label_Command_4->setText(QApplication::translate("MainWindow", "Averaging Iteration", 0));
        pushBtn_Clear->setText(QApplication::translate("MainWindow", "Clear", 0));
        pushBtn_Zoom_Reset->setText(QApplication::translate("MainWindow", "Zoom Reset", 0));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
